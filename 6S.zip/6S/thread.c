/* ====================================================================
 * thread.c  -  Thread, Scheduler Round Robin (preemptive), Mutex, Deadlock
 *
 * Konsep singkat:
 *  - Setiap thread punya TCB (Thread Control Block) berisi status & stack sendiri.
 *  - Status thread: NEW -> READY -> RUNNING -> WAITING -> TERMINATED
 *  - Timer (1000x/detik) memanggil sched_tick(). Jika jatah waktu (quantum)
 *    habis, CPU dipindah ke thread READY berikutnya (context switch).
 *  - Mutex memblokir thread (WAITING) bila kunci sedang dipegang thread lain.
 * ==================================================================== */
#include "kernel.h"

volatile u32 ticks;              /* detak timer sejak boot (1 tick = 1 ms) */
tcb_t *current;                  /* thread yang sedang memakai CPU */
u32 ctx_switches;                /* jumlah context switch (untuk bukti) */
int quantum_ticks = DEFAULT_QUANTUM;   /* QUANTUM Round Robin, bisa diubah lewat shell */
mutex_t *mutex_registry[MAX_MUTEXES];
int mutex_count;
const char *state_name[] = { "UNUSED", "NEW", "READY", "RUNNING", "WAITING", "TERMINATED" };

static tcb_t threads[MAX_THREADS];     /* tabel semua thread */
static int next_tid = 1;
static int quantum_left;               /* sisa jatah waktu thread yang sedang jalan */

/* Mengubah quantum. Berlaku segera untuk jatah waktu yang sedang berjalan. */
void sched_set_quantum(int q) {
    u32 f = irq_save();
    quantum_ticks = q;
    quantum_left = q;
    irq_restore(f);
}

/* Thread 0 = shell (memakai stack boot). Dibuat saat boot. */
void sched_init(void) {
    memset(threads, 0, sizeof(threads));
    tcb_t *t = &threads[0];
    t->tid = 0;
    kstrcpy(t->name, "shell", sizeof(t->name));
    t->state = TS_RUNNING;
    current = t;
    quantum_left = quantum_ticks;
}
tcb_t *thread_at(int i) { return &threads[i]; }
tcb_t *thread_find(int tid) {
    for (int i = 0; i < MAX_THREADS; i++)
        if (threads[i].state != TS_UNUSED && threads[i].tid == tid) return &threads[i];
    return NULL;
}

/* ---------------- Membuat thread: status NEW ----------------
 * Stack thread diisi "bingkai interupsi palsu" supaya saat CPU pertama kali
 * "kembali dari interupsi" (iret), ia langsung lompat ke fungsi entry(). */
tcb_t *thread_create(const char *name, void (*entry)(void), void *arg) {
    u32 f = irq_save();
    tcb_t *t = NULL;
    for (int i = 1; i < MAX_THREADS; i++)
        if (threads[i].state == TS_UNUSED) { t = &threads[i]; break; }
    if (!t) { irq_restore(f); return NULL; }          /* tabel penuh */
    u8 *stk = kmalloc(STACK_SIZE);
    if (!stk) { irq_restore(f); return NULL; }        /* memori habis */
    memset(t, 0, sizeof(*t));
    t->tid = next_tid++;
    kstrcpy(t->name, name, sizeof(t->name));
    t->stack = stk;
    t->arg = arg;
    u32 *sp = (u32 *)(stk + STACK_SIZE);
    *--sp = (u32)thread_exit;   /* alamat kembali: jika entry() selesai, thread berakhir rapi */
    *--sp = 0x202;              /* EFLAGS (IF=1 : interupsi aktif) */
    *--sp = 0x08;               /* CS  (segmen kode kernel) */
    *--sp = (u32)entry;         /* EIP (fungsi pertama yang dijalankan) */
    *--sp = 0;                  /* kode error (kosong) */
    *--sp = 0;                  /* nomor interupsi (kosong) */
    for (int i = 0; i < 8; i++) *--sp = 0;   /* 8 register umum (pusha) */
    t->esp = (u32)sp;
    t->state = TS_NEW;
    irq_restore(f);
    return t;
}
/* NEW -> READY : thread boleh dijadwalkan */
void thread_start(tcb_t *t) {
    u32 f = irq_save();
    if (t && t->state == TS_NEW) t->state = TS_READY;
    irq_restore(f);
}

/* ---------------- SCHEDULER ROUND ROBIN ----------------
 * Cari thread READY berikutnya, berputar mulai dari thread setelah current. */
static tcb_t *pick_next(void) {
    int start = (int)(current - threads);
    for (int i = 1; i <= MAX_THREADS; i++) {
        tcb_t *c = &threads[(start + i) % MAX_THREADS];
        if (c->state == TS_READY) return c;
    }
    return NULL;
}
/* Context switch: simpan stack thread lama, kembalikan stack thread baru.
 * (Pergantian register sebenarnya dilakukan boot.S lewat pusha/popa/iret.) */
u32 schedule(u32 esp) {
    current->esp = esp;
    if (current->state == TS_RUNNING) current->state = TS_READY;   /* RUNNING -> READY */
    tcb_t *n = pick_next();
    if (n) {
        if (n != current) ctx_switches++;
        current = n;
        current->state = TS_RUNNING;                               /* READY -> RUNNING */
    }
    quantum_left = quantum_ticks;                                  /* jatah waktu baru */
    return current->esp;
}
/* Dipanggil setiap 1 ms oleh timer. */
u32 sched_tick(u32 esp) {
    ticks++;
    if (current->state == TS_RUNNING) current->cpu_ticks++;
    for (int i = 0; i < MAX_THREADS; i++) {                        /* bangunkan thread yang tidur */
        tcb_t *t = &threads[i];
        if (t->state == TS_WAITING && t->sleeping && ticks >= t->wake_tick) {
            t->sleeping = 0;
            t->state = TS_READY;                                   /* WAITING -> READY */
        }
    }
    /* Preemption: jatah habis (atau thread sudah tidak RUNNING) => ganti thread */
    if (--quantum_left <= 0 || current->state != TS_RUNNING) return schedule(esp);
    return esp;
}

void thread_yield(void) { __asm__ volatile("int $0x80" ::: "memory"); }   /* serahkan CPU secara sukarela */
void idle_wait(void)    { thread_yield(); __asm__ volatile("hlt"); }       /* tunggu tanpa membakar CPU */

/* Tidur ms milidetik: RUNNING -> WAITING -> READY */
void thread_sleep(u32 ms) {
    u32 f = irq_save();
    current->wake_tick = ticks + ms;
    current->sleeping = 1;
    current->wait_on = NULL;
    current->state = TS_WAITING;
    irq_restore(f);
    thread_yield();
}

/* ---------------- MUTEX ---------------- */
void mutex_init(mutex_t *m, const char *name) {
    m->name = name; m->locked = 0; m->owner = NULL;
    if (mutex_count < MAX_MUTEXES) mutex_registry[mutex_count++] = m;
}
/* Lepas kunci dan bangunkan semua thread yang menunggu kunci ini */
static void release_mutex(mutex_t *m) {
    m->locked = 0;
    m->owner = NULL;
    for (int i = 0; i < MAX_THREADS; i++)
        if (threads[i].state == TS_WAITING && threads[i].wait_on == m) {
            threads[i].state = TS_READY;
            threads[i].wait_on = NULL;
        }
}
/* Ambil kunci. Jika sedang dipegang thread lain => thread ini WAITING. */
void mutex_lock(mutex_t *m) {
    for (;;) {
        u32 f = irq_save();                    /* cek+ambil kunci harus tak terputus */
        if (!m->locked) {
            m->locked = 1; m->owner = current; current->wait_on = NULL;
            irq_restore(f);
            return;
        }
        current->wait_on = m;                  /* catat: saya menunggu kunci m */
        current->state = TS_WAITING;
        irq_restore(f);
        thread_yield();                        /* CPU diberikan ke thread lain */
    }
}
int mutex_unlock(mutex_t *m) {
    u32 f = irq_save();
    if (!m->locked || m->owner != current) { irq_restore(f); return -1; }
    release_mutex(m);
    irq_restore(f);
    return 0;
}

/* ---------------- Mengakhiri thread ---------------- */
static void release_all_owned(tcb_t *t) {       /* lepas semua kunci milik thread t */
    for (int i = 0; i < mutex_count; i++)
        if (mutex_registry[i]->owner == t) release_mutex(mutex_registry[i]);
}
void thread_exit(void) {                        /* RUNNING -> TERMINATED */
    u32 f = irq_save();
    release_all_owned(current);
    current->state = TS_TERMINATED;
    irq_restore(f);
    for (;;) thread_yield();
}
int thread_kill(int tid) {                      /* dipakai untuk recovery deadlock */
    u32 f = irq_save();
    tcb_t *t = thread_find(tid);
    if (!t || t == current || t->tid == 0 || t->state == TS_TERMINATED) { irq_restore(f); return -1; }
    release_all_owned(t);
    t->state = TS_TERMINATED;
    t->sleeping = 0;
    t->wait_on = NULL;
    irq_restore(f);
    return 0;
}
/* Bebaskan stack thread TERMINATED dan kosongkan slotnya */
void thread_reap(void) {
    u32 f = irq_save();
    for (int i = 1; i < MAX_THREADS; i++) {
        tcb_t *t = &threads[i];
        if (t->state == TS_TERMINATED && t != current) {
            kfree(t->stack); t->stack = NULL; t->state = TS_UNUSED;
        }
    }
    irq_restore(f);
}

/* ---------------- DETEKSI DEADLOCK (Wait-for Graph) ----------------
 * Ti -> Tj artinya: Ti menunggu mutex yang dipegang Tj.
 * Jika mengikuti panah kembali ke titik awal => ada siklus => DEADLOCK. */
int deadlock_detect(int verbose, tcb_t **victim) {
    for (int i = 0; i < MAX_THREADS; i++) {
        tcb_t *s = &threads[i];
        if (s->state != TS_WAITING || !s->wait_on) continue;
        tcb_t *c = s;
        int steps = 0, found = 0;
        while (c && c->state == TS_WAITING && c->wait_on && steps <= MAX_THREADS) {
            c = c->wait_on->owner;
            steps++;
            if (c == s) { found = 1; break; }
        }
        if (!found) continue;
        tcb_t *vic = s;                         /* korban = thread ber-tid terbesar dalam siklus */
        if (verbose) kprintf("  Siklus wait-for: ");
        c = s;
        do {
            if (verbose) kprintf("T%d(%s) --[mutex %s]--> ", c->tid, c->name, c->wait_on->name);
            if (c->tid > vic->tid) vic = c;
            c = c->wait_on->owner;
        } while (c != s);
        if (verbose) kprintf("T%d(%s)\n", s->tid, s->name);
        if (victim) *victim = vic;
        return 1;
    }
    return 0;
}
/* Resource Allocation Graph versi teks: siapa memegang & siapa meminta */
void rag_dump(void) {
    kprintf("Resource Allocation Graph (R = mutex, T = thread)\n");
    for (int i = 0; i < mutex_count; i++) {
        mutex_t *m = mutex_registry[i];
        kprintf("  R[%s]: ", m->name);
        if (m->locked) kprintf("dipegang T%d(%s)", m->owner->tid, m->owner->name);
        else kprintf("bebas");
        int first = 1;
        for (int k = 0; k < MAX_THREADS; k++)
            if (threads[k].state == TS_WAITING && threads[k].wait_on == m) {
                kprintf(first ? "  | diminta oleh: " : ", ");
                first = 0;
                kprintf("T%d(%s)", threads[k].tid, threads[k].name);
            }
        kprintf("\n");
    }
}
