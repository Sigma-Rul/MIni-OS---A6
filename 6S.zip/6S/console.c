#include "kernel.h"

#define COM1 0x3F8
static volatile u16 *const vga = (volatile u16 *)0xB8000;
static int row, col;
static u8 color = 0x07;
static int shift;

static void serial_init(void) {
    outb(COM1 + 1, 0x00); outb(COM1 + 3, 0x80);
    outb(COM1 + 0, 0x01); outb(COM1 + 1, 0x00);   /* 115200 baud */
    outb(COM1 + 3, 0x03); outb(COM1 + 2, 0xC7); outb(COM1 + 4, 0x0B);
}
static void serial_put(char c) {
    for (int i = 0; i < 100000; i++) if (inb(COM1 + 5) & 0x20) break;
    outb(COM1, (u8)c);
}
static void vga_cursor(void) {
    u16 pos = (u16)(row * 80 + col);
    outb(0x3D4, 14); outb(0x3D5, pos >> 8);
    outb(0x3D4, 15); outb(0x3D5, pos & 0xFF);
}
static void vga_scroll(void) {
    for (int i = 0; i < 24 * 80; i++) vga[i] = vga[i + 80];
    for (int i = 24 * 80; i < 25 * 80; i++) vga[i] = (u16)(' ' | (color << 8));
    row = 24;
}
static void vga_put(char c) {
    if (c == '\n') { col = 0; row++; }
    else if (c == '\r') col = 0;
    else if (c == '\b') { if (col > 0) col--; }
    else if (c == '\t') { col = (col + 8) & ~7; }
    else { vga[row * 80 + col] = (u16)((u8)c | (color << 8)); col++; }
    if (col >= 80) { col = 0; row++; }
    if (row >= 25) vga_scroll();
    vga_cursor();
}
void kputc(char c) {
    if (c == '\n') serial_put('\r');
    serial_put(c);
    vga_put(c);
}
void cons_clear(void) {
    for (int i = 0; i < 80 * 25; i++) vga[i] = (u16)(' ' | (color << 8));
    row = col = 0; vga_cursor();
    for (const char *e = "\x1b[2J\x1b[H"; *e; e++) serial_put(*e);   /* clear serial terminal only */
}
void cons_init(void) { serial_init(); cons_clear(); }

static const char kb_lower[] = "\0\0" "1234567890-=" "\b\t" "qwertyuiop[]" "\n\0" "asdfghjkl;'`" "\0\\" "zxcvbnm,./" "\0*\0 ";
static const char kb_upper[] = "\0\0" "!@#$%^&*()_+" "\b\t" "QWERTYUIOP{}" "\n\0" "ASDFGHJKL:\"~" "\0|" "ZXCVBNM<>?" "\0*\0 ";

int cons_poll(void) {
    if (inb(COM1 + 5) & 1) {                       /* serial input */
        char c = (char)inb(COM1);
        if (c == '\r') return '\n';
        if (c == 0x7F) return '\b';
        return (u8)c;
    }
    u8 st = inb(0x64);
    if ((st & 1) && !(st & 0x20)) {                /* PS/2 keyboard */
        u8 sc = inb(0x60);
        if (sc == 0x2A || sc == 0x36) { shift = 1; return -1; }
        if (sc == 0xAA || sc == 0xB6) { shift = 0; return -1; }
        if (sc & 0x80 || sc == 0xE0 || sc >= sizeof(kb_lower) - 1) return -1;
        char c = shift ? kb_upper[sc] : kb_lower[sc];
        return c ? (u8)c : -1;
    }
    return -1;
}
int cons_getc(void) {
    int c;
    while ((c = cons_poll()) < 0) idle_wait();
    return c;
}
