#ifndef KERNEL_H
#define KERNEL_H

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
#ifndef NULL
#define NULL ((void *)0)
#endif

/* ---------- low level helpers ---------- */
#ifdef HOSTTEST
static inline u32  irq_save(void) { return 0; }
static inline void irq_restore(u32 f) { (void)f; }
#include <string.h>
#else
static inline void outb(u16 p, u8 v)  { __asm__ volatile("outb %0,%1" :: "a"(v), "Nd"(p)); }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0,%1" :: "a"(v), "Nd"(p)); }
static inline u8   inb(u16 p)         { u8 v; __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline u32  irq_save(void)     { u32 f; __asm__ volatile("pushf; pop %0; cli" : "=r"(f) :: "memory"); return f; }
static inline void irq_restore(u32 f) { __asm__ volatile("push %0; popf" :: "r"(f) : "memory", "cc"); }
void *memset(void *d, int c, u32 n);
void *memcpy(void *d, const void *s, u32 n);
u32   strlen(const char *s);
int   strcmp(const char *a, const char *b);
#endif
void kstrcpy(char *d, const char *s, u32 max);
int  katoi(const char *s);

/* ---------- console ---------- */
void cons_init(void);
void cons_clear(void);
void kputc(char c);
void kputs(const char *s);
void kprintf(const char *fmt, ...);
int  cons_poll(void);      /* non-blocking, -1 if none */
int  cons_getc(void);      /* blocking (yields CPU while waiting) */

/* ---------- cpu / interrupts ---------- */
void gdt_init(void);
void idt_init(void);
void pic_init(void);
void pit_init(u32 hz);

/* ---------- threads / scheduler / sync ---------- */
enum { TS_UNUSED = 0, TS_NEW, TS_READY, TS_RUNNING, TS_WAITING, TS_TERMINATED };
#define MAX_THREADS    12
#define MAX_MUTEXES    8
#define STACK_SIZE     8192
#define DEFAULT_QUANTUM 5         /* quantum awal = 5 ms (timer PIT 1000 Hz => 1 tick = 1 ms) */

struct mutex;
typedef struct tcb {
    int   tid;
    char  name[16];
    int   state;
    u32   esp;
    u8   *stack;
    void *arg;
    struct mutex *wait_on;
    u32   wake_tick;
    int   sleeping;
    u32   cpu_ticks;
    u32   result;
} tcb_t;

typedef struct mutex {
    const char *name;
    volatile int locked;
    tcb_t *owner;
} mutex_t;

extern volatile u32 ticks;
extern tcb_t *current;
extern u32 ctx_switches;
extern int quantum_ticks;          /* quantum Round Robin saat ini (ms), bisa diubah */
void   sched_set_quantum(int q);
extern mutex_t *mutex_registry[MAX_MUTEXES];
extern int mutex_count;
extern const char *state_name[];

void   sched_init(void);
u32    schedule(u32 esp);
u32    sched_tick(u32 esp);
void   thread_yield(void);
void   idle_wait(void);
tcb_t *thread_create(const char *name, void (*entry)(void), void *arg);
void   thread_start(tcb_t *t);
void   thread_exit(void);
int    thread_kill(int tid);
void   thread_sleep(u32 ms);
void   thread_reap(void);
tcb_t *thread_at(int i);
tcb_t *thread_find(int tid);
void   mutex_init(mutex_t *m, const char *name);
void   mutex_lock(mutex_t *m);
int    mutex_unlock(mutex_t *m);
int    deadlock_detect(int verbose, tcb_t **victim);
void   rag_dump(void);

/* ---------- memory ---------- */
#define HEAP_SIZE (512 * 1024)
typedef struct { u32 total, used, free, used_blocks, free_blocks, largest_free; } memstat_t;
void  mem_init(void);
void *kmalloc(u32 n);
void  kfree(void *p);
void  mem_stats(memstat_t *s);

/* ---------- ramdisk file system ---------- */
#define MAX_FILES 16
#define NAME_LEN  16
#define PERM_R 4
#define PERM_W 2
#define FS_OK      0
#define FS_ENOENT -1
#define FS_EACCES -2
#define FS_EEXIST -3
#define FS_ENOSPC -4
#define FS_EINVAL -5
typedef struct {
    int  used;
    char name[NAME_LEN];
    int  owner;
    u8   perm_owner, perm_other;
    char *data;
    u32  size;
} file_t;
void    fs_init(void);
int     fs_create(const char *name, int uid);
int     fs_write(const char *name, const char *txt, u32 len, int uid, int append);
int     fs_read(const char *name, int uid, const char **data, u32 *size);
int     fs_delete(const char *name, int uid);
int     fs_chmod(const char *name, int uid, int mode);
file_t *fs_at(int i);
const char *fs_strerror(int e);

/* ---------- shell ---------- */
extern int cur_uid;
void shell_main(void);

#endif
