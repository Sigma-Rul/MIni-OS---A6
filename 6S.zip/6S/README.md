# 6S (Operating Six)
Menjalankan di Windows: install QEMU (https://www.qemu.org/download/#windows), taruh 6s.elf dan jalankan.bat sefolder, klik dua kali jalankan.bat.
Perintah manual: qemu-system-i386 -kernel 6s.elf
Linux/WSL: sudo apt install build-essential gcc-multilib qemu-system-x86 make ; make ; make run
Skenario uji: lihat SKENARIO_PENGUJIAN.md. Password root saat 'su root' dari guest: 6s
