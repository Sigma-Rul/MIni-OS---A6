/* First-fit heap allocator with block splitting and coalescing */
#include "kernel.h"

#define BLK_MAGIC 0xB10CB10Cu
typedef struct blk { u32 size, free, magic, pad; struct blk *next, *prev; } blk_t;

static u8 heap[HEAP_SIZE] __attribute__((aligned(16)));
static blk_t *head;

void mem_init(void) {
    head = (blk_t *)heap;
    head->size = HEAP_SIZE - sizeof(blk_t); head->free = 1; head->magic = BLK_MAGIC;
    head->next = head->prev = NULL;
}
void *kmalloc(u32 n) {
    if (n == 0 || n > HEAP_SIZE) return NULL;
    n = (n + 7) & ~7u;
    u32 f = irq_save();
    for (blk_t *b = head; b; b = b->next) {
        if (!b->free || b->size < n) continue;
        if (b->size >= n + sizeof(blk_t) + 8) {            /* split */
            blk_t *nb = (blk_t *)((u8 *)(b + 1) + n);
            nb->size = b->size - n - sizeof(blk_t); nb->free = 1; nb->magic = BLK_MAGIC;
            nb->next = b->next; nb->prev = b;
            if (b->next) b->next->prev = nb;
            b->next = nb; b->size = n;
        }
        b->free = 0;
        irq_restore(f);
        return (void *)(b + 1);
    }
    irq_restore(f);
    return NULL;                                           /* Out of Memory: caller must handle */
}
void kfree(void *p) {
    if (!p) return;
    u32 f = irq_save();
    blk_t *b = (blk_t *)p - 1;
    if ((u8 *)b < heap || (u8 *)p >= heap + HEAP_SIZE || b->magic != BLK_MAGIC || b->free) {
        irq_restore(f);
        kprintf("kfree: invalid pointer or double free ignored\n");
        return;
    }
    b->free = 1;
    if (b->next && b->next->free) {                        /* merge with next */
        b->next->magic = 0;
        b->size += sizeof(blk_t) + b->next->size;
        b->next = b->next->next;
        if (b->next) b->next->prev = b;
    }
    if (b->prev && b->prev->free) {                        /* merge with previous */
        blk_t *pv = b->prev;
        b->magic = 0;
        pv->size += sizeof(blk_t) + b->size;
        pv->next = b->next;
        if (b->next) b->next->prev = pv;
    }
    irq_restore(f);
}
void mem_stats(memstat_t *s) {
    memset(s, 0, sizeof(*s));
    s->total = HEAP_SIZE;
    u32 f = irq_save();
    for (blk_t *b = head; b; b = b->next) {
        if (b->free) { s->free += b->size; s->free_blocks++; if (b->size > s->largest_free) s->largest_free = b->size; }
        else { s->used += b->size; s->used_blocks++; }
    }
    irq_restore(f);
}
