# 6S (Operating Six) - Skenario Pengujian

Setelah boot muncul logo "6S" dan prompt `root@6s#`. Ketik `skenario` untuk melihat peta ringkas di dalam OS.
Ambil screenshot SETELAH tiap skenario selesai (untuk Bab III laporan).

Alur umum kernel: Timer (1000x/detik) -> interupsi -> `sched_tick()` -> jika quantum habis -> `schedule()` memilih
thread READY berikutnya -> `boot.S` menukar stack (context switch) -> `iret` melanjutkan thread baru.

---------------------------------------------------------------------
## 1. Bootstrapping & CLI
Perintah: `help`, `about`, `uptime`   (juga `skenario`, `ps`, dll. = lebih dari 3 perintah buatan sendiri)
Yang terlihat: logo ASCII, baris [ OK ] tiap komponen, prompt, lalu hasil tiap perintah.
Alur: QEMU memuat 6s.elf ke RAM (multiboot) -> `_start` di boot.S -> `kmain()` menyalakan GDT, IDT, PIC, heap,
scheduler, RAMDisk, timer -> `shell_main()` membaca keyboard/serial.
Lulus bila: OS boot di QEMU dan >= 3 perintah berjalan.

## 2. Proses & Thread (status)
Perintah: `threads`
Yang terlihat (4 tabel `ps`):
 (1) setelah thread_create  -> prime-calc & sleeper berstatus NEW
 (2) setelah thread_start   -> READY
 (3) saat berjalan          -> campuran RUNNING / READY / WAITING (sleeper sedang tidur)
 (4) setelah selesai        -> TERMINATED
Alur: `thread_create` membuat TCB + stack (NEW) -> `thread_start` (READY) -> scheduler memilih (RUNNING) ->
`thread_sleep` (WAITING) -> timer membangunkan (READY) -> fungsi selesai -> `thread_exit` (TERMINATED).
Lulus bila: 2 thread dengan tugas berbeda dan kelima status tampil.

## 3. Penjadwalan Round Robin (quantum bisa diubah)
Perintah:
    quantum 5      (lihat nilai: `quantum`)
    sched
    quantum 50
    sched
    quantum 1
    sched
Yang terlihat: 3 thread (A,B,C) mencetak huruf tiap 10 ms CPU.
 - quantum 5 / 1 : pola rapat bergantian  ABCABCABC...
 - quantum 50    : pola berkelompok       AAAAABBBBBCCCCC...
 - jumlah "context switch" turun drastis saat quantum besar (kira-kira 1200/quantum, mis. ~240 vs ~24).
Alur: tiap thread loop tanpa yield(); hanya timer yang memaksa pindah. Quantum disimpan di `quantum_ticks`;
perintah `quantum` mengubahnya lewat `sched_set_quantum()`.
Lulus bila: pola huruf bergantian (bukan printf simulasi) dan berubah mengikuti quantum.

## 4. Sinkronisasi & Race Condition
Perintah: `race` lalu `race sync`
Yang terlihat:
 - `race`      : hasil < 200000 (ada "hilang" > 0)  => RACE CONDITION  (angka berbeda tiap run)
 - `race sync` : hasil = 200000, hilang = 0           => KONSISTEN
Alur: 2 thread melakukan baca-tmp-tulis(tmp+1) pada 1 counter. Tanpa mutex, thread bisa terputus timer di
antara baca dan tulis sehingga update tertimpa. Dengan mutex, bagian itu (critical section) hanya dimasuki 1 thread.

## 5. Deadlock
Perintah (berurutan):
    deadlock            # skenario: T1 kunci A lalu B, T2 kunci B lalu A
    rag                 # (opsional) graf alokasi resource
    deadlock recover    # root: korban dihentikan
    deadlock fix        # pencegahan: urutan kunci A lalu B
Yang terlihat:
 - `deadlock`: kedua thread berstatus WAITING (mutex B / mutex A), muncul "Siklus wait-for: T1 -> T2 -> T1",
   dan penjelasan 4 kondisi deadlock.
 - `deadlock recover`: korban dihentikan, thread lain selesai, "sistem pulih".
 - `deadlock fix`: kedua thread TERMINATED normal.
Alur: tiap thread memegang 1 mutex lalu minta mutex satunya (hold & wait). `mutex_lock` mengubah status jadi
WAITING dan mencatat `wait_on`. Deteksi: ikuti rantai "menunggu mutex milik siapa"; kembali ke awal = siklus.
Pencegahan: semua thread mengambil mutex berurutan (A=1 sebelum B=2) sehingga circular wait mustahil.
Catatan: jalankan `deadlock recover` sebelum `deadlock fix`.

## 6. Alokator Memori Dinamis
Perintah: `memtest` (otomatis) atau manual: `meminfo`, `malloc 1000`, `meminfo`, `free 0`, `meminfo`, `malloc 99999999`
Yang terlihat: angka terpakai/tersedia berubah; setelah semua dibebaskan blok bebas menyatu kembali
(coalescing); saat memori habis `kmalloc` mengembalikan NULL dan muncul pesan Out of Memory, kernel TIDAK crash.
Alur: heap 512 KB berisi daftar blok (header + data). Alokasi = first-fit + pecah blok; pembebasan = tandai bebas
lalu gabungkan dengan tetangga bebas.

## 7. Virtual File System (RAMDisk) - CRUD
Perintah: `fstest` (otomatis) atau manual:
    touch a.txt
    write a.txt halo
    cat a.txt
    append a.txt  dunia
    cat a.txt
    rm a.txt
    ls
Yang terlihat: Create, Read, Update (tulis/tambah), Delete berhasil; membaca file terhapus -> "No such file".
Alur: tabel 16 berkas; isi tiap berkas disimpan di heap (kmalloc), diganti/ditambah dengan menyalin ke buffer baru.

## 8. Proteksi & Hak Akses
Perintah: `prottest` (otomatis), lalu manual:
    write secret.txt rahasia
    chmod secret.txt 60
    su guest
    cat secret.txt        # DITOLAK
    write guest.txt hai   # DIIZINKAN
    kill 1                # DITOLAK (butuh root)
    su root               # password: 6s
Yang terlihat: akses yang diizinkan berhasil, yang tidak diizinkan ditolak ("Permission denied"); prottest
menampilkan LULUS di semua baris.
Alur: setiap operasi berkas memeriksa uid peminta vs pemilik dan bit hak (6=rw, 4=r, 0=tidak ada); root melewati
pemeriksaan. Perintah sistem tertentu (kill, reboot, shutdown, deadlock recover) hanya untuk root.
