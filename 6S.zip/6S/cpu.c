#include "kernel.h"

struct gdt_entry { u16 limit_low, base_low; u8 base_mid, access, gran, base_high; } __attribute__((packed));
struct gdt_ptr   { u16 limit; u32 base; } __attribute__((packed));
struct idt_entry { u16 base_lo, sel; u8 zero, flags; u16 base_hi; } __attribute__((packed));
struct frame { u32 edi, esi, ebp, esp_dummy, ebx, edx, ecx, eax, int_no, err, eip, cs, eflags; };

static struct gdt_entry gdt[3];
static struct idt_entry idt[256];
extern u32 isr_table[32];
extern void irq0_stub(void);
extern void yield_stub(void);

static void gdt_set(int i, u32 base, u32 limit, u8 access, u8 gran) {
    gdt[i].base_low = base & 0xFFFF; gdt[i].base_mid = (base >> 16) & 0xFF; gdt[i].base_high = base >> 24;
    gdt[i].limit_low = limit & 0xFFFF; gdt[i].gran = ((limit >> 16) & 0x0F) | (gran & 0xF0);
    gdt[i].access = access;
}
void gdt_init(void) {
    struct gdt_ptr gp = { sizeof(gdt) - 1, (u32)gdt };
    gdt_set(0, 0, 0, 0, 0);
    gdt_set(1, 0, 0xFFFFF, 0x9A, 0xCF);   /* kernel code */
    gdt_set(2, 0, 0xFFFFF, 0x92, 0xCF);   /* kernel data */
    __asm__ volatile("lgdt %0\n\t"
                     "mov $0x10, %%ax\n\t"
                     "mov %%ax, %%ds\n\t" "mov %%ax, %%es\n\t" "mov %%ax, %%fs\n\t"
                     "mov %%ax, %%gs\n\t" "mov %%ax, %%ss\n\t"
                     "ljmp $0x08, $1f\n\t" "1:\n\t" :: "m"(gp) : "ax", "memory");
}
static void idt_set(int n, u32 h) {
    idt[n].base_lo = h & 0xFFFF; idt[n].base_hi = h >> 16;
    idt[n].sel = 0x08; idt[n].zero = 0; idt[n].flags = 0x8E;
}
void idt_init(void) {
    struct { u16 limit; u32 base; } __attribute__((packed)) ip = { sizeof(idt) - 1, (u32)idt };
    for (int i = 0; i < 32; i++) idt_set(i, isr_table[i]);
    idt_set(32, (u32)irq0_stub);
    idt_set(0x80, (u32)yield_stub);
    __asm__ volatile("lidt %0" :: "m"(ip));
}
void pic_init(void) {
    outb(0x20, 0x11); outb(0xA0, 0x11);
    outb(0x21, 32);   outb(0xA1, 40);
    outb(0x21, 4);    outb(0xA1, 2);
    outb(0x21, 1);    outb(0xA1, 1);
    outb(0x21, 0xFE); outb(0xA1, 0xFF);   /* only IRQ0 (timer) enabled */
}
void pit_init(u32 hz) {
    u32 div = 1193182 / hz;
    outb(0x43, 0x36); outb(0x40, div & 0xFF); outb(0x40, (div >> 8) & 0xFF);
}

static const char *exc_name[] = {
    "Divide Error", "Debug", "NMI", "Breakpoint", "Overflow", "Bound Range", "Invalid Opcode",
    "Device N/A", "Double Fault", "Coproc Overrun", "Invalid TSS", "Segment Not Present",
    "Stack Fault", "General Protection", "Page Fault", "Reserved", "x87 FPU", "Alignment Check",
    "Machine Check", "SIMD FP" };

/* Called from isr_common. Returns the stack pointer of the thread to resume. */
u32 isr_dispatch(u32 esp) {
    struct frame *f = (struct frame *)esp;
    if (f->int_no == 32) { outb(0x20, 0x20); return sched_tick(esp); }
    if (f->int_no == 128) return schedule(esp);
    kprintf("\n*** KERNEL PANIC: exception %u (%s) err=%x eip=%x ***\n", f->int_no,
            f->int_no < 20 ? exc_name[f->int_no] : "Reserved", f->err, f->eip);
    for (;;) __asm__ volatile("cli; hlt");
    return esp;
}
