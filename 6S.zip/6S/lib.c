#include "kernel.h"
#include <stdarg.h>

void *memset(void *d, int c, u32 n) { u8 *p = d; while (n--) *p++ = (u8)c; return d; }
void *memcpy(void *d, const void *s, u32 n) { u8 *a = d; const u8 *b = s; while (n--) *a++ = *b++; return d; }
u32 strlen(const char *s) { u32 n = 0; while (s[n]) n++; return n; }
int strcmp(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return (u8)*a - (u8)*b; }
void kstrcpy(char *d, const char *s, u32 max) {
    u32 i = 0;
    if (!max) return;
    for (; i < max - 1 && s[i]; i++) d[i] = s[i];
    d[i] = 0;
}
int katoi(const char *s) { int v = 0; while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; } return v; }

void kputs(const char *s) { while (*s) kputc(*s++); }

/* minimal printf: %d %u %x %c %s %%  with  -  0  and width */
void kprintf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    u32 fl = irq_save();
    for (; *fmt; fmt++) {
        if (*fmt != '%') { kputc(*fmt); continue; }
        fmt++;
        int left = 0, zero = 0, width = 0;
        if (*fmt == '-') { left = 1; fmt++; }
        if (*fmt == '0') { zero = 1; fmt++; }
        while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        if (!*fmt) break;
        char tmp[16];
        const char *s = tmp;
        int len = 0;
        switch (*fmt) {
        case 'd': case 'u': {
            u32 u; int neg = 0;
            if (*fmt == 'd') { int v = va_arg(ap, int); if (v < 0) { neg = 1; u = (u32)(-v); } else u = (u32)v; }
            else u = va_arg(ap, u32);
            char r[12]; int n = 0;
            do { r[n++] = '0' + (u % 10); u /= 10; } while (u);
            if (neg) tmp[len++] = '-';
            while (n) tmp[len++] = r[--n];
            break; }
        case 'x': {
            u32 u = va_arg(ap, u32);
            char r[12]; int n = 0;
            do { r[n++] = "0123456789abcdef"[u & 15]; u >>= 4; } while (u);
            while (n) tmp[len++] = r[--n];
            break; }
        case 'c': tmp[0] = (char)va_arg(ap, int); len = 1; break;
        case 's': s = va_arg(ap, const char *); if (!s) s = "(null)"; len = (int)strlen(s); break;
        case '%': tmp[0] = '%'; len = 1; break;
        default:  tmp[0] = '%'; tmp[1] = *fmt; len = 2; break;
        }
        if (!left) for (int k = len; k < width; k++) kputc(zero ? '0' : ' ');
        for (int k = 0; k < len; k++) kputc(s[k]);
        if (left) for (int k = len; k < width; k++) kputc(' ');
    }
    irq_restore(fl);
    va_end(ap);
}
