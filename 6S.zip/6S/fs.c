/* RAM-disk file system (flat directory) with owner/other permissions */
#include "kernel.h"

static file_t files[MAX_FILES];

static file_t *lookup(const char *name) {
    for (int i = 0; i < MAX_FILES; i++) if (files[i].used && !strcmp(files[i].name, name)) return &files[i];
    return NULL;
}
static int can(file_t *f, int uid, int want) {
    if (uid == 0) return 1;                                   /* root bypasses checks */
    u8 bits = (uid == f->owner) ? f->perm_owner : f->perm_other;
    return (bits & want) == want;
}
const char *fs_strerror(int e) {
    switch (e) {
    case FS_OK: return "OK"; case FS_ENOENT: return "No such file";
    case FS_EACCES: return "Permission denied"; case FS_EEXIST: return "File exists";
    case FS_ENOSPC: return "No space left (out of memory/slots)"; default: return "Invalid argument";
    }
}
void fs_init(void) {
    memset(files, 0, sizeof(files));
    const char *t = "Welcome to VortexOS RAMDisk.";
    fs_write("readme.txt", t, strlen(t), 0, 0);
}
int fs_create(const char *name, int uid) {
    if (!name[0] || strlen(name) >= NAME_LEN) return FS_EINVAL;
    if (lookup(name)) return FS_EEXIST;
    for (int i = 0; i < MAX_FILES; i++) if (!files[i].used) {
        files[i].used = 1; kstrcpy(files[i].name, name, NAME_LEN);
        files[i].owner = uid; files[i].perm_owner = PERM_R | PERM_W; files[i].perm_other = PERM_R;
        files[i].data = NULL; files[i].size = 0;
        return FS_OK;
    }
    return FS_ENOSPC;
}
int fs_write(const char *name, const char *txt, u32 len, int uid, int append) {
    file_t *f = lookup(name);
    if (!f) { int r = fs_create(name, uid); if (r) return r; f = lookup(name); }
    if (!can(f, uid, PERM_W)) return FS_EACCES;
    u32 base = (append && f->data) ? f->size : 0;
    char *nb = kmalloc(base + len + 1);
    if (!nb) return FS_ENOSPC;                                /* old content untouched */
    if (base) memcpy(nb, f->data, base);
    memcpy(nb + base, txt, len);
    nb[base + len] = 0;
    if (f->data) kfree(f->data);
    f->data = nb; f->size = base + len;
    return FS_OK;
}
int fs_read(const char *name, int uid, const char **data, u32 *size) {
    file_t *f = lookup(name);
    if (!f) return FS_ENOENT;
    if (!can(f, uid, PERM_R)) return FS_EACCES;
    *data = f->data ? f->data : ""; *size = f->size;
    return FS_OK;
}
int fs_delete(const char *name, int uid) {
    file_t *f = lookup(name);
    if (!f) return FS_ENOENT;
    if (uid != 0 && uid != f->owner) return FS_EACCES;
    if (f->data) kfree(f->data);
    memset(f, 0, sizeof(*f));
    return FS_OK;
}
int fs_chmod(const char *name, int uid, int mode) {            /* mode = two digits: owner,other (0..7) */
    file_t *f = lookup(name);
    if (!f) return FS_ENOENT;
    if (uid != 0 && uid != f->owner) return FS_EACCES;
    f->perm_owner = (u8)((mode / 10) & 6); f->perm_other = (u8)((mode % 10) & 6);
    return FS_OK;
}
file_t *fs_at(int i) { return (i >= 0 && i < MAX_FILES) ? &files[i] : NULL; }
